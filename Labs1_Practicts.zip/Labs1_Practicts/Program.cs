﻿using System;
using System.Threading;

namespace Labs1_Practicts
{
    internal class Program
    {
        static int[] array = { 2, 3, 4, 5 }; //Массив

        static long result1 = 1; // переменная для произведения первой половины массива (Поток 1)
        static long result2 = 1; // переменная для произведения второй половины массива (Поток 2)

        static object lockObject = new object(); // объект для блокировки доступа к переменным результатов из разных потоков

        static void Main()
        {
            // Создаем и запускаем потоки для обработки каждой половины массива
            Thread t1 = new Thread(() => CalculateResult(0, array.Length / 2, ref result1));
            Thread t2 = new Thread(() => CalculateResult(array.Length / 2, array.Length, ref result2));

            t1.Start();
            t2.Start();

            t1.Join();
            t2.Join();

            Console.WriteLine("Произведение Потока 1: " + result1);
            Console.WriteLine("Произведение Потока 2: " + result2);

            long finalResult = result1 * result2;
            Console.WriteLine("Произведение двух потоков: " + finalResult);
            Console.ReadKey();
        }

        static void CalculateResult(int start, int end, ref long result)
        {
            for (int i = start; i < end; i++)
            {5
                lock (lockObject)
                {
                    result *= array[i];
                }
            }
        }
    }
}